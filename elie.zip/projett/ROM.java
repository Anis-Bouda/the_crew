public class ROM extends Composant {
	// Tableau pour stocker les données
	private State[] memory;
	// la taille de la memoire 
	private static final int MEMORY_SIZE = 256;
	
	 public ROM(String id, int x, int y) {
	        super(id, x, y);
	        this.memory = new State[MEMORY_SIZE];
	        
	        for(int i =0; i<MEMORY_SIZE; i++) {
	        	memory[i] = State.UNKNOWN;
	        }
	        // l'adresse
	        this.addInput(State.UNKNOWN);
	        // la sortie dans la lecture 
	        this.addOutput(State.UNKNOWN);
	  }
@Override	 
	 public void evaluate() {
	        if (this.inputs.size() == 1 && this.outputs.size() == 1) {
	           // on recupere les inputs 
	        	  State adresse = this.inputs.get(0);
	        	  State outputs = State.UNKNOWN;
	        
	              if(adresse == State.UNKNOWN) {
	            	  outputs = State.UNKNOWN;
	              }
	              else {
	            	  // convertir l'adresse
	            	  int address = adresse.ordinal() % MEMORY_SIZE;
 	            	   outputs = memory[address];
	              }
	        	  this.outputs.set(0, outputs);
      }
  else {
      throw new IllegalStateException("Erreur d'évaluation : La ROM doit avoir exactement 1 entrée et 1 sortie.");
  }
}
@Override
public boolean equals(Object obj) {
	if (this == obj) {
		return true;
	}
	if (!super.equals(obj)) {
		return false;
	}
	ROM rom = (ROM)obj;
	boolean res=true;
	if(this.memory.length!=rom.memory.length)
	{
		return false;
	}

	for(int i=0;i<this.memory.length;i++)
	{
		res= res && this.memory[i]== rom.memory[i];
	}
	return res;
}

@Override
public String toString() {
	return super.toString() + ", MEMORY :" + java.util.Arrays.toString(this.memory);
}

@Override
public int hashCode() {
	int res = super.hashCode();
	for (State s : this.memory) {
        res = res * 31 + (s != null ? s.hashCode() : 0);
    }
	return res;
}
}