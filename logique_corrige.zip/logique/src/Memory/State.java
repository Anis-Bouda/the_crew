package Memory;

public enum State {
        TRUE,
        FALSE,
        UNKNOWN,
        ERROR,
    
}
