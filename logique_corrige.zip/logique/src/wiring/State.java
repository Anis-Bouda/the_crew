package wiring;

public enum State {
        TRUE,
        FALSE,
        UNKNOWN,
        ERROR,
    
}
