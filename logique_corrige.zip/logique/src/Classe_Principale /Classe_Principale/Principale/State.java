package Classe_Principale .Classe_Principale.Principale;


public enum State {
        TRUE,
        FALSE,
        UNKNOWN,
        ERROR,
    
}
