package Memory;

public enum ShiftType {
      LOGIQUE,
      ARITHMETIQUE,
      CIRCULAIRE,
}

