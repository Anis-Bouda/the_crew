package GRAPHIQUE;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;

public class ReadInputCount {
    public static int getInputCount(String filename) {
        int count = 0;
        try {
            File file = new File(filename);
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = builder.parse(file);
            NodeList componentNodes = doc.getElementsByTagName("component");

            for (int i = 0; i < componentNodes.getLength(); i++) {
                Element component = (Element) componentNodes.item(i);
                String name = component.getElementsByTagName("name").item(0).getTextContent();
                if (name.startsWith("GENERATOR")) {
                    count++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }
}
