package Logique.wiring;

public enum ExtensionType {
      ZERO,
      ONE,
      SIGN,
}

