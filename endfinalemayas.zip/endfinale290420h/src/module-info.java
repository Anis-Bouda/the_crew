module projetfinale {
    // Déclarez les modules nécessaires
    requires java.base;        // Pour les classes de base de Java
    requires java.desktop;     // Pour java.awt, javax.swing, etc.
    requires java.xml;         // Si vous travaillez avec des fichiers XML
    requires java.compiler;    // Pour javax.lang.model.element.Element

}
