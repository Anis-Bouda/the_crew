package projet;

public enum ExtensionType {
      ZERO,
      ONE,
      SIGN,
}
