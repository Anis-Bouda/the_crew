package projet;

public enum ShiftType {
      LOGIQUE,
      ARITHMETIQUE,
      CIRCULAIRE,
}
