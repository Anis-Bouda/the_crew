package projet;

public enum State {
	    True,
        False,
        UNKNOWN,
        ERROR,
}

