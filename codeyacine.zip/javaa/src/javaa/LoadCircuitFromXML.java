import org.w3c.dom.*;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.awt.*;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class LoadCircuitFromXML extends JPanel {

    private Map<AbstractComponent, Point> composantsMap = new HashMap<>();

    public LoadCircuitFromXML() {
        this.setLayout(null); // positionnement absolu
    }

    public void loadCircuitFromXML(File file) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(file);
            doc.getDocumentElement().normalize();

            NodeList nodeList = doc.getElementsByTagName("component");

            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);

                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;

                    String name = element.getElementsByTagName("name").item(0).getTextContent();
                    int x = Integer.parseInt(element.getElementsByTagName("x").item(0).getTextContent());
                    int y = Integer.parseInt(element.getElementsByTagName("y").item(0).getTextContent());

                    AbstractComponent component;
                    if (name.startsWith("saved_")) {
                        component = new LED("LED1", x, y); // tu peux changer ça par une factory plus tard
                        ComposantPanel.addSavedComponent(name); // ✅ On ajoute dynamiquement dans le JTree
                    } else {
                        component = createGraphicalComponent(name);
                    }

                    if (component != null) {
                        component.setBounds(x, y, component.getPreferredSize().width, component.getPreferredSize().height);
                        composantsMap.put(component, new java.awt.Point(x, y));

                        // On vérifie que le conteneur a bien un JLayeredPane
                        for (Component c : getComponents()) {
                            if (c instanceof JLayeredPane layeredPane) {
                                layeredPane.add(component, Integer.valueOf(2));
                                break;
                            }
                        }
                    }
                }
            }

            repaint();
            revalidate();

            JOptionPane.showMessageDialog(this, "Circuit chargé avec succès !");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erreur lors du chargement du circuit.");
        }
    }

    private AbstractComponent createGraphicalComponent(String name) {
        AbstractComponent newComponent = null;
        switch (name) {
            case "NOT":
                newComponent = new NOT_ig();
                break;
            case "OR":
                newComponent = new OR_ig(); // à implémenter si ce n'est pas fait
                break;
            // Ajoute d'autres composants ici
            default:
                System.err.println("Composant inconnu : " + name);
        }
        return newComponent;
    }
}
