package Logique.Memory;


public enum ShiftType {
      LOGIQUE,
      ARITHMETIQUE,
      CIRCULAIRE,
}

