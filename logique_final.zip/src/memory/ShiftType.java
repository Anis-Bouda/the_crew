package memory;


public enum ShiftType {
      LOGIQUE,
      ARITHMETIQUE,
      CIRCULAIRE,
}

