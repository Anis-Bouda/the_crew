package memory;


public enum State {
        TRUE,
        FALSE,
        UNKNOWN,
        ERROR,
    
}
