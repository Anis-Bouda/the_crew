package classe_principale .classe_principale.principale;



public enum State {
        TRUE,
        FALSE,
        UNKNOWN,
        ERROR,
    
}
