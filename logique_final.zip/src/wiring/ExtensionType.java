package wiring;


public enum ExtensionType {
      ZERO,
      ONE,
      SIGN,
}

